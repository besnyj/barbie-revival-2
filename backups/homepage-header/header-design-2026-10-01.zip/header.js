const origin = location.origin;
const rewriteRules = [
  [/^https?:\/\/(?:www\.)?barbie\.com(?::80)?\//i, origin + '/'],
  [/^https?:\/\/icanbe\.barbie\.com\//i, origin + '/_original/icanbe.barbie.com/'],
  [new RegExp('^https?://((?!'+location.host.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?:/|$))[^/]+)/','i'), origin + '/_external/$1/'],
];
window.RufflePlayer = {config:{autoplay:'on',unmuteOverlay:'hidden',splashScreen:false,contextMenu:'off',warnOnUnsupportedContent:false,logLevel:'warn',wmode:'transparent',allowScriptAccess:true,openUrlMode:'allow',urlRewriteRules:rewriteRules,publicPath:'/vendor/ruffle/'}};
const noop = ()=>{};
window.trackAction=noop; window.trackClick=noop; window.trackEvent=noop;
window.Tracker={track:noop,enableShortCuts:noop};
window.MATTEL={tracker:{Tracker:window.Tracker}};
window.utag={link:noop,view:noop};
window.updateBackground = index => {
  const n = Math.max(0,Math.min(2,Number(index)||0))+1;
  document.getElementById('background').style.backgroundImage = `url('/images/header/0${n}BG.jpg')`;
};
window.ChangeBackgroundImage=window.updateBackground;
async function movie(container,url,width,height,parameters={}) {
  const player=window.RufflePlayer.newest().createPlayer();
  player.style.width=width+'px'; player.style.height=height+'px';
  container.append(player);
  const api=player.ruffle(); api.volume=0;
  await api.load({url,parameters,base:new URL('.',new URL(url,origin)).href});
  api.volume=0;
}
window.addEventListener('DOMContentLoaded',async()=>{
  await Promise.allSettled([
    movie(document.getElementById('navigation'),'/global/barbie_nav_new.swf?v=2',820,100,{cat:'homepage'}),
    movie(document.getElementById('shop'),'/global/shop_barbie_btn.swf',131,140)
  ]);
});
