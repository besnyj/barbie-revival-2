# Backup do design atual do cabeçalho da home

Criado em 01/10/2026, antes de alterações visuais. Este ZIP contém apenas o cabeçalho de 990 × 210 px da home, seus fundos visíveis, menu e botão Shop animados (SWF), seletor de país e o Ruffle necessário para reproduzir as animações. Os três fundos 01BG/02BG/03BG foram incluídos porque o carrossel da home alterna a arte atrás do cabeçalho. Não inclui os slides, promos ou outras seções da página.

- `header-fragment.html`: marcação exata do `<header>` no `public/index.html` no momento do backup.
- `header.css`: regras do `public/site.css` que afetam o cabeçalho, na ordem original da cascata.
- `header.js`: configuração e inicialização das duas animações, isoladas do restante da aplicação. A prévia é para conferir o visual; a navegação e a troca de país dependem das demais rotas e funções da aplicação completa.
- `header-preview.html`: página isolada para inspecionar o cabeçalho. Após extrair, sirva a pasta extraída por HTTP na raiz (por exemplo `python3 -m http.server 8000`) e acesse `/header-preview.html`. Não abra via `file://`.
- `images/`, `global/`, `vendor/ruffle/`: arquivos visuais e runtime necessários.
- `MANIFEST.json`: SHA-256 de cada arquivo para checagem.

Para restaurar no projeto, compare `header-fragment.html`, `header.css` e `header.js` com os arquivos atuais antes de reintegrar. As referências de mídia preservam os caminhos `/images`, `/global` e `/vendor/ruffle` do site.
