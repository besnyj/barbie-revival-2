# Cabeçalho antes da redução — 01/10/2026

Backup tirado imediatamente antes de remover o banner "The pink world is back!" e reduzir a altura do cabeçalho. Inclui cópias exatas dos três arquivos de código ativos (HTML, JS e CSS), dos elementos visuais do cabeçalho, do menu animado e do runtime Ruffle, com caminhos relativos ao projeto. Os arquivos de código contêm também trechos fora do cabeçalho porque sua cópia integral permite reverter sem perder a configuração exata. Compare alterações posteriores antes de restaurar.

O botão Donate e a bolsa já haviam sido removidos antes deste backup. O SWF original da bolsa está em `backups/header-bag/`.
