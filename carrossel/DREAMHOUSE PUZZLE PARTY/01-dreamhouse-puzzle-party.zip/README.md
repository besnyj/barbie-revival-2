# Backup do slide: Dreamhouse Puzzle Party

Este ZIP preserva os arquivos da homepage no momento do backup. Os caminhos dentro de `public/` correspondem aos caminhos originais no projeto.

## Conteúdo específico
- Animação do slide: `public/global/homepageCDARotation/DreamhousePuzzleParty.swf`
- Plano de fundo: `public/images/header/01BG.jpg`
- Índice do slide/fundo: `0` (base zero)

## Estrutura compartilhada
- `HomeCDA.swf`: controlador, setas e transições do carrossel.
- `HomeCDA.xml`: configuração original completa, com os três slides e tempos de 10 segundos.
- `index.html`, `app.js` e `site.css`: ponto de montagem, ponte de troca do fundo e estilos da homepage.
- `public/vendor/ruffle/`: runtime necessário para reproduzir SWF em navegadores atuais (arquivos .map de depuração excluídos).

## Restauração
1. Para repor somente este slide em um carrossel existente, extraia o SWF e o JPG específicos nos caminhos acima. Confirme que o XML ativo ainda contém a entrada desse slide e que o código da homepage ainda chama `HomeCDA.swf` e `updateBackground`.
2. Para repor o carrossel completo a partir dos backups, extraia os três ZIPs na raiz do projeto. Os arquivos compartilhados são cópias idênticas; restaure `index.html`, `app.js` e `site.css` somente após comparar com a versão atual, pois eles também contêm outras partes do site.
3. A restauração por extração não altera automaticamente a configuração se o XML tiver sido editado depois deste backup. Reinsira a entrada necessária no XML ou restaure sua cópia original.

O diretório extraído `public/global/homepageCDARotation/MyDreamhouse/` contém imagens de inspeção, não é necessário para executar o SWF e não faz parte deste backup.
Verifique a integridade de cada arquivo com `MANIFEST.json` (SHA-256).
